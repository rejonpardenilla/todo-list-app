# todo-list-app
A firebase, jquery and foundation todo list app
