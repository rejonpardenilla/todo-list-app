(function() {

  window.location.href = "app.html";

}());
